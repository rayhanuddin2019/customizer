</div><!-- #content -->



 <?php   get_template_part( 'template-parts/footer/footer', 'style-1' ); ?>
 </div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
